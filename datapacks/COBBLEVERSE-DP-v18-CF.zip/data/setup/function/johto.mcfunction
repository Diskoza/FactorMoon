datapack enable COBBLEVERSE-Johto-DP.zip
tellraw @a [{"text":" [IMPORTANT]","color":"dark_red"},{"text":" The world / server must be closed and reopened for the new region to become active.","color":"gold"}]
tellraw @a [{"text":" If you're the host, please REBOOT your world or server NOW.","bold":true,"color":"red"}]
tellraw @a [{"text":" JOHTO will be installed automatically after the reboot!","color":"green"}]
tellraw @a [{"text":" No data will be lost or reset.","italic":true,"color":"gray"}]